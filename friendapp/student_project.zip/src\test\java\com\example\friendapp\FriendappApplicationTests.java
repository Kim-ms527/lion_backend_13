package com.example.friendapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FriendappApplicationTests {

	@Test
	void contextLoads() {
	}

}
